# PROG5121 Part 1 

This is an alternative implementation of the same Part 1 registration and login requirements.

The implementation uses different variable names and a different program structure while retaining the required application behaviour and method names from the POE.


