package com.mycompany.prog5121part1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * PROG5121 Part 1 - Registration and Login Application.
 *
 * 
 * 
 * 
 * 
 * @author Nandi Nkosi
 */
public class Prog5121part1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Login> accountList = new ArrayList<>();

        showApplication(input, accountList);

        input.close();
    }

    private static void showApplication(Scanner input,
                                         ArrayList<Login> accountList) {

        boolean running = true;

        System.out.println("\nWelcome to the Registration and Login App!");

        while (running) {
            displayMenu();
            String menuChoice = input.nextLine();

            if (menuChoice.equals("1")) {
                createAccount(input, accountList);
            } else if (menuChoice.equals("2")) {
                authenticateAccount(input, accountList);
            } else if (menuChoice.equals("3")) {
                System.out.println("\nGoodbye!");
                running = false;
            } else {
                System.out.println("\nInvalid option. Please choose 1, 2 or 3.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nMain Menu:");
        System.out.println("1. Register");
        System.out.println("2. Login");
        System.out.println("3. Exit");
        System.out.print("Please choose an option: ");
    }

    private static void createAccount(Scanner input,
                                      ArrayList<Login> accountList) {

        System.out.println("\n=== Registration ===");

        System.out.print("Enter your first name: ");
        String first = input.nextLine();

        System.out.print("Enter your last name: ");
        String last = input.nextLine();

        System.out.print("Enter username: ");
        String newUsername = input.nextLine();

        System.out.print("Enter password: ");
        String newPassword = input.nextLine();

        System.out.print("Enter a South African cell phone number "
                + "(e.g. +27838968976): ");
        String newPhone = input.nextLine();

        Login account = new Login(
                newUsername,
                newPassword,
                newPhone,
                first,
                last
        );

        System.out.println("\n" + account.registerUser());

        if (!account.checkUserName()
                || !account.checkPasswordComplexity()
                || !account.checkCellPhoneNumber()) {

            System.out.println("Registration was not completed.");
            return;
        }

        if (usernameAlreadyUsed(accountList, newUsername)) {
            System.out.println("Username already exists. "
                    + "Please choose another username.");
            return;
        }

        accountList.add(account);
        System.out.println("User registered successfully!");
        System.out.println("You can now choose Login from the Main Menu.");
    }

    private static boolean usernameAlreadyUsed(
            ArrayList<Login> accountList, String candidate) {

        for (Login account : accountList) {
            if (account.getUsername().equals(candidate)) {
                return true;
            }
        }

        return false;
    }

    private static void authenticateAccount(
            Scanner input, ArrayList<Login> accountList) {

        if (accountList.isEmpty()) {
            System.out.println("\nNo users are registered yet. "
                    + "Please register first.");
            return;
        }

        System.out.println("\nLogin");

        System.out.print("Enter username: ");
        String loginName = input.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = input.nextLine();

        Login matchedAccount = findAccount(accountList, loginName);

        if (matchedAccount == null) {
            System.out.println(
                    "Username or password incorrect, please try again."
            );
            return;
        }

        boolean authenticated = matchedAccount.loginUser(
                loginName,
                loginPassword
        );

        System.out.println(
                matchedAccount.returnLoginStatus(authenticated)
        );
    }

    private static Login findAccount(
            ArrayList<Login> accountList, String requestedUsername) {

        for (Login account : accountList) {
            if (account.getUsername().equals(requestedUsername)) {
                return account;
            }
        }

        return null;
    }
}
