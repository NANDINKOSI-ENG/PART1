package com.mycompany.prog5121part1;

import java.util.regex.Pattern;

/**
 * Handles registration validation and login authentication.
 *
 * Regular expression reference:
 * Oracle Java Documentation, Pattern class:
 * https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/regex/Pattern.html
 *
 * 
 * 
 * 
 * @author Nandi Shannon Nkosi
 
 * 
 * 
 */
public class Login {

    private String userId;
    private String secret;
    private String mobileNumber;
    private String givenName;
    private String familyName;

    public Login(String userId, String secret, String mobileNumber,
                 String givenName, String familyName) {
        this.userId = userId;
        this.secret = secret;
        this.mobileNumber = mobileNumber;
        this.givenName = givenName;
        this.familyName = familyName;
    }

    public boolean checkUserName() {
        if (userId == null || userId.length() > 5) {
            return false;
        }

        return userId.contains("_");
    }

    public boolean checkPasswordComplexity() {
        if (secret == null || secret.length() < 8) {
            return false;
        }

        boolean capitalFound = false;
        boolean numberFound = false;
        boolean specialFound = false;

        for (int index = 0; index < secret.length(); index++) {
            char current = secret.charAt(index);

            if (Character.isUpperCase(current)) {
                capitalFound = true;
            } else if (Character.isDigit(current)) {
                numberFound = true;
            } else if (!Character.isLetterOrDigit(current)) {
                specialFound = true;
            }
        }

        return capitalFound && numberFound && specialFound;
    }

    public boolean checkCellPhoneNumber() {
        if (mobileNumber == null) {
            return false;
        }

        String southAfricanMobilePattern = "^\\+27[6-8]\\d{8}$";
        return Pattern.matches(southAfricanMobilePattern, mobileNumber);
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure "
                    + "that your username contains an underscore and is no "
                    + "more than five characters in length.";
        }

        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure "
                    + "that the password contains at least eight characters, "
                    + "a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not "
                    + "contain international code.";
        }

        return "Username successfully captured.\n"
                + "Password successfully captured.\n"
                + "Cell phone number successfully added.";
    }

    public boolean loginUser(String suppliedUsername, String suppliedPassword) {
        boolean usernameMatches = userId != null
                && userId.equals(suppliedUsername);

        boolean passwordMatches = secret != null
                && secret.equals(suppliedPassword);

        return usernameMatches && passwordMatches;
    }

    public String returnLoginStatus(boolean authenticated) {
        if (authenticated) {
            return "Welcome " + givenName + " " + familyName
                    + " it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }

    public String getUsername() {
        return userId;
    }
}
