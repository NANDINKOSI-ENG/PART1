package com.mycompany.prog5121part1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Login class.
 *
 * @author Nandi Shannon Nkosi
 */
public class LoginTest {

}
